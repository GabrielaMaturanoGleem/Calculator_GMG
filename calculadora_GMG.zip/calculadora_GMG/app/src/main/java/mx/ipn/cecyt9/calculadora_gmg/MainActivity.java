package mx.ipn.cecyt9.calculadora_gmg;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText n1;
    EditText n2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
    }


    public void potencia(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = (float)Math.pow(num1, num2);

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }


    public void raiz(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = (float)Math.pow(num1, 1/num2);

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }

    public void sumar(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = num1 + num2;

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }

    public void restar(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = num1 - num2;

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }

    public void multiplicar(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = num1 * num2;

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }

    public void dividir(View view){
        float num1;
        float num2;
        float resultado;

        num1 = Integer.parseInt(n1.getText().toString());
        num2 = Integer.parseInt(n2.getText().toString());

        resultado = num1 / num2;

        Toast msj = Toast.makeText(getApplication(), "Resultado "+resultado, Toast.LENGTH_SHORT);
        msj.show();
    }

}
